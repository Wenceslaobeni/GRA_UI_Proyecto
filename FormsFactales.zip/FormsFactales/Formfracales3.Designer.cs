﻿namespace FormsFactales
{
    partial class Formfracales3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            ptb3 = new PictureBox();
            ((System.ComponentModel.ISupportInitialize)ptb3).BeginInit();
            SuspendLayout();
            // 
            // ptb3
            // 
            ptb3.Dock = DockStyle.Fill;
            ptb3.Location = new Point(0, 0);
            ptb3.Name = "ptb3";
            ptb3.Size = new Size(532, 503);
            ptb3.TabIndex = 0;
            ptb3.TabStop = false;
            // Formfracales3
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(532, 503);
            Controls.Add(ptb3);
            Name = "Formfracales3";
            Text = "Formfracales3";
            ((System.ComponentModel.ISupportInitialize)ptb3).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private PictureBox ptb3;
    }
}